        clear
        clc
        close all
        run data.m;   %读取系统参数
        run Market_data_processing; %读取系统需求、VPP投标等信息        
        run Market_clearing;         %运行市场出清    
        run out_figure;              %画图





















