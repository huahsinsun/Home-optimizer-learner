    %将优化结果进行绘图
    %将市场电价、负荷等数据绘图
    %市场电价
    figure(1)
    subplot(2,2,1)
    plot(E_Price24);
    xlabel('时间(Hour)');
    ylabel('能量市场预测电价（元/MWh）');
    subplot(2,2,2)
    plot(RM_Price24);
    xlabel('时间(Hour)');
    ylabel('备用市场电价元（元/MWh）');
    subplot(2,2,3)
    plot(Reg_cap_price24);
    xlabel('时间(Hour)');
    ylabel('调频容量市场电价（元/MWh）');
    subplot(2,2,4)
    plot(Reg_mil_price24);
    xlabel('时间(Hour)');
    ylabel('调频里程市场电价（元/MW）');

    %VPP投标电量（报量模式）
    figure(2)
    subplot(2,2,1)
    plot(VPP_P);
    xlabel('时间(Hour)');
    ylabel('能量市场投标量（MWh）');
    subplot(2,2,2)
    plot(VPP_R);
    xlabel('时间(Hour)');
    ylabel('备用市场投标量（MWh）');
    subplot(2,2,3)
    plot(VPP_Reg_cap);
    xlabel('时间(Hour)');
    ylabel('调频容量市场投标量（MWh）');
    subplot(2,2,4)
    plot(VPP_Reg_mil);
    xlabel('时间(Hour)');
    ylabel('调频里程市场投标量（MW）');










