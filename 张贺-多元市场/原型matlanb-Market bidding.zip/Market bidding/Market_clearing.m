
    VPP_P=sdpvar(1,24,'full');%VPP整体购电量
    VPP_R=sdpvar(1,24,'full');%VPP整体购买备用量
    VPP_Reg_cap=sdpvar(1,24,'full');%VPP整体购买的调频容量
    VPP_Reg_mil=sdpvar(1,24,'full');%VPP整体购买的调频里程
    
    GEN_P=sdpvar(Conventional_GEN_Number,24,'full');%。 各GEN有功功率出清量
    GEN_R=sdpvar(Conventional_GEN_Number,24,'full');%。 各GEN备用功率出清量
    GEN_Reg_cap=sdpvar(Conventional_GEN_Number,24,'full');%。 各GEN调频容量出清量
    GEN_Reg_mil=sdpvar(Conventional_GEN_Number,24,'full');%。 各GEN调频里程出清量

    storage_P_in=sdpvar(Conventional_storage_Number,24,'full');
    storage_P_out=sdpvar(Conventional_storage_Number,24,'full');
    storage_R=sdpvar(Conventional_storage_Number,24,'full');%。 各储能备用功率出清量
    storage_Reg_cap=sdpvar(Conventional_storage_Number,24,'full');%。 各储能调频容量出清量
    storage_Reg_mil=sdpvar(Conventional_storage_Number,24,'full');%。 各储能调频里程出清量
    storage_E=sdpvar(Conventional_storage_Number,25,'full');%。 各储能有功功率出清量
    alpha_1=binvar(Conventional_storage_Number,24,'full');%储能的充放电限制，储能不可以同时充放电
    alpha_2=binvar(Conventional_storage_Number,24,'full');
    
    P_wind=sdpvar(1,24,'full');%风能的出力
    P_pv=sdpvar(1,24,'full');%光伏的出力
    %%
    %约束条件



    Cons = [];    
    Constraints_GEN=[];    
    Constraints_storage=[];
    Constraints_VPP=[];
    Constraints_wind_pv=[];
    Constraints_P_balance=[];
    Constraints_R_balance=[];
    Constraints_Reg_cap_balance=[];
    Constraints_Reg_mil_balance=[];
    Constraints_System_balance=[];




    for i=1:24
    %储能出力约束
    Constraints_VPP = [Constraints_VPP, -VPP_P_limit <= VPP_P(i) <= VPP_P_limit];
    Constraints_VPP = [Constraints_VPP, -VPP_R_limit <= VPP_R(i) <= VPP_R_limit];
    Constraints_VPP = [Constraints_VPP, -VPP_Reg_cap_limit <= VPP_Reg_cap(i) <= VPP_Reg_cap_limit];
    Constraints_VPP = [Constraints_VPP, -VPP_Reg_mil_limit <= VPP_Reg_mil(i) <= VPP_Reg_mil_limit];
    Constraints_VPP = [Constraints_VPP,  VPP_P(i) + VPP_R(i) + VPP_Reg_cap(i)<= VPP_P_limit];
    Constraints_VPP = [Constraints_VPP, -VPP_P_limit <= VPP_P(i) - VPP_Reg_cap(i)];

    Constraints_GEN= [Constraints_GEN, GEN_P_min <= GEN_P(:,i) <= GEN_P_max];
    Constraints_GEN= [Constraints_GEN, GEN_R_min <= GEN_R(:,i) <= GEN_R_max];
    Constraints_GEN= [Constraints_GEN, GEN_Reg_cap_min <= GEN_Reg_cap(:,i) <= GEN_Reg_cap_max];
    Constraints_GEN= [Constraints_GEN, GEN_Reg_mil_min <= GEN_Reg_mil(:,i) <= GEN_Reg_mil_max];
    Constraints_GEN= [Constraints_GEN, GEN_Reg_cap(:,i)*0.2 <= GEN_Reg_mil(:,i) <=GEN_Reg_cap(:,i)*20 ];  %0.5为调频设备的最小利用率
    Constraints_GEN= [Constraints_GEN, GEN_P(:,i)+GEN_R(:,i)+GEN_Reg_cap(:,i) <= GEN_P_max];  %有功、调频和备用之间的上限耦合
    Constraints_GEN= [Constraints_GEN, GEN_P_min <= GEN_P(:,i)-GEN_Reg_cap(:,i)];        %有功、调频和备用之间的下限耦合
    



    Constraints_storage= [Constraints_storage, 0 <= storage_P_in(:,i) <=storage_P_max.*alpha_1(:,i)];
    Constraints_storage= [Constraints_storage, 0 <= storage_P_out(:,i) <=storage_P_max.*alpha_2(:,i)];
    Constraints_storage= [Constraints_storage, alpha_1(:,i)+alpha_2(:,i)<=1*ones(Conventional_storage_Number,1)];
    Constraints_storage= [Constraints_storage, storage_R_min <= storage_R(:,i) <= storage_R_max];
    Constraints_storage= [Constraints_storage, storage_Reg_cap_min <= storage_Reg_cap(:,i) <= storage_Reg_cap_max];
    Constraints_storage= [Constraints_storage, storage_Reg_mil_min <= storage_Reg_mil(:,i) <= storage_Reg_mil_max];
    Constraints_storage= [Constraints_storage, storage_Reg_cap(:,i)*0.2 <= storage_Reg_mil(:,i) <=storage_Reg_cap(:,i)*20 ];  %0.5为调频设备的最小利用率
    Constraints_storage= [Constraints_storage, storage_P_in(:,i) + storage_R(:,i)+storage_Reg_cap(:,i) <= storage_P_max];  %有功、调频和备用之间的上限耦合
    Constraints_storage= [Constraints_storage, storage_P_out(:,i) + storage_R(:,i)+storage_Reg_cap(:,i) <= storage_P_max];  %有功、调频和备用之间的上限耦合
    Constraints_storage= [Constraints_storage, 0 <= storage_P_in(:,i) - storage_Reg_cap(:,i)];        %有功、调频和备用之间的下限耦合
    Constraints_storage= [Constraints_storage, 0 <= storage_P_out(:,i) - storage_Reg_cap(:,i)];        %有功、调频和备用之间的下限耦合


    Constraints_storage= [Constraints_storage, storage_E(:,1) == storage_E0.*storage_cap]; %储能能量约束
    Constraints_storage= [Constraints_storage, storage_E(:,25) == storage_E24.*storage_cap]; %储能始末能量控制约束

        for ess_j = 1:Conventional_storage_Number

            Constraints_storage= [Constraints_storage, storage_E(ess_j,i+1) == storage_E(ess_j,i) - storage_P_out(ess_j,i)/theta(ess_j)+storage_P_in(ess_j,i)*theta(ess_j)]; %储能约束
            Constraints_storage= [Constraints_storage, storage_E_min(ess_j)*storage_cap(ess_j) <= storage_E(ess_j,i+1) <= storage_E_max(ess_j)*storage_cap(ess_j)]; %储能约束
        end
    Constraints_wind_pv=[Constraints_wind_pv,0 <= P_wind(i) <= P_wind_forecast(i)]  
    Constraints_wind_pv=[Constraints_wind_pv,0 <= P_pv(i) <= P_pv_forecast(i)]  
   
    %系统有功、调频容量、调频里程、备用平衡  
    Constraints_P_balance = [Constraints_P_balance, VPP_P(i)==sum(GEN_P(:,i))+sum(storage_P_out(:,i))-sum(storage_P_in(:,i))+P_wind(i)+P_pv(i)-Bus_load_P_MW24(i) ]; 
    Constraints_R_balance = [Constraints_R_balance, VPP_R(i)==sum(GEN_R(:,i)) + sum(storage_R(:,i))  - 1*R_total_demand_MW24(i)];
    Constraints_Reg_cap_balance = [Constraints_Reg_cap_balance, VPP_Reg_cap(i)==sum(GEN_Reg_cap(:,i)) + sum(storage_Reg_cap(:,i)) - 1*Reg_cap_total_demand_MW24(i)];
    Constraints_Reg_mil_balance = [Constraints_Reg_mil_balance, VPP_Reg_mil(i)==sum(GEN_Reg_mil(:,i)) + sum(storage_Reg_mil(:,i)) - 1*Reg_mil_total_demand_MW24(i)];

    Constraints_System_balance=[Constraints_System_balance,Constraints_wind_pv,Constraints_P_balance,Constraints_R_balance,Constraints_Reg_cap_balance,Constraints_Reg_mil_balance];
    end

    Cons=[Constraints_storage,Constraints_GEN,Constraints_VPP,Constraints_System_balance];
    %%
    %目标函数
    Objective1 = 0;
    Objective2 = 0;
    Objective = 0;    
    %虚拟电厂内部分布式发电机组运行成本
    %机组有功成本，二次函数形式
    for prig_i=1:Conventional_GEN_Number
        for t=1:24
        Objective1 = Objective1 +a(prig_i)*GEN_P(prig_i,t)^2+b(prig_i)*GEN_P(prig_i,t)+c(prig_i);
        end
    end
    %机组备用、调频、里程成本
    Objective1 = Objective1 + sum(sum(GEN_R,2).*GEN_RM_price) + sum(sum(GEN_Reg_cap,2).*GEN_Reg_cap_price) + sum(sum(GEN_Reg_mil,2).*GEN_Reg_mil_price);
    %虚拟电厂内部储能运行成本
    Objective1 = Objective1  + sum((sum(storage_P_in,2)+sum(storage_P_out,2)).*storage_p_price)+sum(sum(storage_R,2).*storage_RM_price) + sum(sum(storage_Reg_cap,2).*storage_Reg_cap_price) + sum(sum(storage_Reg_mil,2).*storage_Reg_mil_price);
    %虚拟电厂整体对外购入/出售
    Objective2 = Objective2 + sum(VPP_P.*E_Price24)  + sum(VPP_R.*RM_Price24) + sum(VPP_Reg_cap.*Reg_cap_price24) + sum(VPP_Reg_mil.*Reg_mil_price24) ; 
    Objective =Objective1-Objective2 ;

    warning('off','YALMIP:strict') 
    % ops = sdpsettings('verbose',1,'debug',1);
    ops = sdpsettings('verbose',1,'solver','gurobi');
    sol = optimize(Cons,Objective,ops);
%     clc
   
    VPP_P=double(VPP_P);
    VPP_R=double(VPP_R);
    VPP_Reg_cap=double(VPP_Reg_cap);
    VPP_Reg_mil=double(VPP_Reg_mil);
    GEN_P=double(GEN_P);
    GEN_R=double(GEN_R);
    GEN_Reg_cap=double(GEN_Reg_cap);
    GEN_Reg_mil=double(GEN_Reg_mil);
    storage_P_in=double(storage_P_in);
    storage_P_out=double(storage_P_out);
    storage_R=double(storage_R);
    storage_Reg_cap=double(storage_Reg_cap);
    storage_Reg_mil=double(storage_Reg_mil);

    