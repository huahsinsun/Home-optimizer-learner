    Conventional_GEN_Number=size(gen,1);
    Conventional_storage_Number=size(storage,1);
    %%
    %系统电价/负荷
    %市场电价曲线有名值（虚拟电厂通过预测得到的）
    load('E_Price24'); %能量市场价格
    load('RM_Price24');  %备用市场价格
    load('Reg_cap_price24'); %调频容量价格
    load('Reg_mil_price24'); %调频里程价格

    %需求侧数据可以直接读取（虚拟电厂内部电能量、备用以及调频里程和调频备用）
    load('Bus_load_P_MW24');%
    load('R_total_demand_MW24');
    load('Reg_cap_total_demand_MW24');
    load('Reg_mil_total_demand_MW24');

    %风光出力预测
    load('P_PV');
    load('P_wind');
    P_wind_forecast=P_wind;
    P_pv_forecast=P_PV;
    
    %%   投标参数信息
     %VPP对外整体投标信息 
    VPP_install_capacity=sum(gen(:,2))+sum(storage(:,2));
    VPP_P_limit=0.2*VPP_install_capacity; %虚拟电厂整体对外输出功率最值
    VPP_R_limit=0.04*VPP_install_capacity; %
    VPP_Reg_cap_limit=0.04*VPP_install_capacity; %
    VPP_Reg_mil_limit=VPP_Reg_cap_limit; %
%     发电机组投标参数信息
    GEN_P_max=gen(:,2);                                         %。 各发电机组有功功率投标最大值
    GEN_P_min=gen(:,3);                                        %。 各发电机组有功功率投标最小值
    GEN_R_max=0.2*gen(:,2);                                     %。 各发电机组备用投标最大值,默认其备用中标备用占总容量的20%
    GEN_R_min=0*ones(Conventional_GEN_Number,1);                %。 各发电机组备用投标最小值,默认0
    GEN_Reg_cap_max=0.15*gen(:,2);                              %。 各发电机组调频容量投标最大值,默认其调频容量中标备用占总容量的15%（广东市场的限制）
    GEN_Reg_cap_min=0*gen(:,2);                                 %。 各发电机组调频容量投标最小值,默认其0
    GEN_Reg_mil_max=5*GEN_Reg_cap_max;                          %。 各发电机组调频里程投标最大值，默认其调频里程/调频容量比例为：5；
    GEN_Reg_mil_min=5*GEN_Reg_cap_min;                          %。 各发电机组调频里程投标最小值，默认其0



    
    %投标参数信息
    %%储能投标范围
    storage_P_max=storage(:,2);                                      %。 各充电功率投标最大值
    storage_R_max=0.2*storage(:,2);                                    %。 各备用投标最大值,默认其备用中标备用占总容量的20%
    storage_R_min=0*ones(Conventional_storage_Number,1);               %。 各备用投标最小值,默认0
    storage_Reg_cap_max=0.15*storage(:,2);                             %。 各调频容量投标最大值,默认其调频容量中标备用占总容量的15%（广东市场的限制）
    storage_Reg_cap_min=0*storage(:,2);                                %。 各调频容量投标最小值,默认其0
    storage_Reg_mil_max=5*storage_Reg_cap_max;                         %。 各调频里程投标最大值，默认其调频里程/调频容量比例为：5；
    storage_Reg_mil_min=5*storage_Reg_cap_min;                         %。 各调频里程投标最小值，默认其0
    storage_E0=storage(:,6);
    storage_cap=storage(:,3);
    storage_E24=storage(:,6);
    storage_E_min=storage(:,5);
    storage_E_max=storage(:,4);
    theta=storage(:,7);%储能充放电效率




    %投标价格 
    %虚拟电厂内部分布式机组成本价格
    %有功运行成本系数
    a=gen(:,4);b=gen(:,5);c=gen(:,6);
    GEN_RM_price=gen(:,7);%给定的值
    GEN_Reg_cap_price=gen(:,8);
    GEN_Reg_mil_price=gen(:,9);
    %%储能运行成本价格
    storage_p_price=storage(:,8);%储能成本系数
    storage_RM_price=storage(:,9);
    storage_Reg_cap_price=storage(:,10);
    storage_Reg_mil_price=storage(:,11);




    

    
    